package com.example.flutter_module

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
